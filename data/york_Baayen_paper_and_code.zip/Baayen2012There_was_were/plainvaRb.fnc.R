plainvaRb.fnc = function(formula, data=datall, plot=TRUE) {

 options(contrasts=c(unordered="contr.sum",ordered="contr.poly"))

 f = as.character(formula)
 dep = f[2]
 success = levels(data[,dep])[2]
 preds = f[3]
 preds = gsub(" *", "", preds)
 preds = strsplit(f[3], "\\+")[[1]]
 for (i in 1:length(preds)) preds[i] = gsub(" ", "", preds[i])

 thefactors = rep(FALSE, length(preds))
 for (i in 1:length(preds)) {
   thefactors[i] = is.factor(data[,preds[i]])
 }
 names(thefactors) = preds

 thefactors = thefactors[thefactors==TRUE]
 data.glm = glm(formula, data=data, family="binomial")

 coefs = data.frame(summary(data.glm)$coef)

 Ntokens = vector(mode="numeric")
 Counts = vector(mode="numeric")
 Props = vector(mode="numeric")
 Probs = vector(mode="numeric")
 Levels = vector(mode="character")
 Factor = vector(mode="character")
 Successes = vector(mode="numeric")
 success = levels(data[,dep])[2]
 Weight = vector(mode="numeric")
 mn = plogis(coefs[1,1]) 
 mn2 = 0.5
 for (f in names(thefactors)) {
   counts = as.numeric(table(data[,f]))
   tab = table(data[,dep], data[,f])
   props = as.numeric(tab[success,]/colSums(tab))
   Counts = c(Counts, counts)
   Successes = c(Successes, as.numeric(tab[success,]))
   Levels = c(Levels, levels(data[,f]))
   Factor = c(Factor, rep(f, length(counts)))
   Props = c(Props, props)

   if (nlevels(data[,f]) == 2) {
     rowname = paste(f, "1", sep="")
     psuccess = plogis(coefs[1,1]+coefs[rowname,"Estimate"])
     pfailure = plogis(coefs[1,1]-coefs[rowname,"Estimate"])
     probs = c(psuccess, pfailure)
     Weight = c(Weight, mn2+(probs-mn))
   } else {
     if (is.ordered(data[,f])) {
       cfs = coefs[grep(f, rownames(coefs)),1]
       probs = plogis((contrasts(data[,f]) %*% cfs))
       Weight = c(Weight, probs)
     }
   }
   Probs = c(Probs, probs)
 }
 dfr = data.frame(Factor, Levels, Successes, Counts, Props, Probs, Weight)
 dfr[,5:7] = round(dfr[,5:7],4)
 dfr[,c(5,7)] = 100*dfr[,c(5,7)]

 colnames(dfr)[5]="Perc"
 
 colnames(coefs) = c("Estimate", "Standard Error", "Z", "p")

 options(contrasts=c(unordered="contr.treatment",ordered="contr.poly"))

 if (plot==TRUE) {
   n = nlevels(dfr$Factor)
   if (n==1) par(mfrow=c(1,1))
   if (n==2) par(mfrow=c(1,2))
   if ((n == 3) || (n==4)) par(mfrow=c(2,2))
   if ((n == 5) || (n==6)) par(mfrow=c(2,3))
   if ((n > 6) & (n <=9)) par(mfrow=c(3,3))
   if ((n > 9) & (n <=12)) par(mfrow=c(3,4))
   if (n > 12) stop("plot not implemented for more than 12 predictors\n")

   for (f in levels(dfr$Factor)) {
     d = dfr[dfr$Factor==f,]
     d$Levels=d$Levels[drop=TRUE]
     if (nlevels(d$Levels) == 2) x = 0.2
     else x=0.5
     plot((1:nlevels(d$Levels))+x-1, d$Probs, ylim=c(0,1), xaxt="n",xlab=" ", 
       ylab="probability",
       xlim=c(0, length(as.numeric(d$Levels))+x*2-1), type="b", yaxp=c(0, 1, 4))
     mtext(as.character(d$Levels), side = 1, line=1, at = (1:nlevels(d$Levels))+x-1, cex=0.8)
   }
   par(mfrow=c(1,1))
 }
 return(list(varbrul = dfr, model = coefs))
}

